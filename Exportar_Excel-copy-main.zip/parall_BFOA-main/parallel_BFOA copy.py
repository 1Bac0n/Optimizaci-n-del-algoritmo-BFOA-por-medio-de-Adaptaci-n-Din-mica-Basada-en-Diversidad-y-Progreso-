from copy import copy
from multiprocessing import Manager, Pool
import time
from bacteria import bacteria
import numpy as np
import copy
import random

from fastaReader import fastaReader

if __name__ == "__main__":
    numeroDeBacterias = 8
    numRandomBacteria = 1
    iteraciones = 8
    tumbo = 300                                             #numero de gaps a insertar 
    nado = 3
    secuencias = list()
    
    secuencias = fastaReader().seqs
    names = fastaReader().names
    
    def pad_poblacion(poblacion, pad_char='-'):
        max_len = max(len(seq) for bact in poblacion for seq in bact)
        for bact_idx, bact in enumerate(poblacion):
            # Convierte la bacteria a lista de listas (por si es tuple)
            bact_list = [list(seq) for seq in bact]
            for seq_idx, seq in enumerate(bact_list):
                if len(seq) < max_len:
                    bact_list[seq_idx] = seq + [pad_char] * (max_len - len(seq))
            # Vuelve a guardar como tuple (si así lo usas en el resto del código)
            poblacion[bact_idx] = tuple(bact_list)

    def diversidad_poblacion_vectorizada(poblacion):
        # Convierte la población a un array 3D: (bacterias, secuencias, longitud)
        arr = np.array([[list(seq) for seq in bact] for bact in poblacion], dtype='<U1')
        n = arr.shape[0]
        distancias = []
        for i in range(n):
            for j in range(i+1, n):
                diffs = arr[i] != arr[j]
                # Promedio de diferencias por secuencia
                d = diffs.sum(axis=1) / diffs.shape[1]
                distancias.append(d.mean())
        return np.mean(distancias)   
    
  
         
    
    
    #hace todas las secuencias listas de caracteres
    for i in range(len(secuencias)):
        #elimina saltos de linea
        secuencias[i] = list(secuencias[i])
        

    

    globalNFE = 0                            #numero de evaluaciones de la funcion objetivo
    
    

    dAttr= 0.1 #0.1
    wAttr= 0.002 #0.2
    hRep=dAttr
    wRep= .001    #10
    
   

  
    
    manager = Manager()
    numSec = len(secuencias)
    print("numSec: ", numSec)
    
    poblacion = manager.list(range(numeroDeBacterias))
    names = manager.list(names)
    NFE = manager.list(range(numeroDeBacterias))
    
    
    # print(secuencias)



    def poblacionInicial():
        for i in range(numeroDeBacterias):
            bacterium = []
            for j in range(numSec):
                seq = secuencias[j][:]
                for _ in range(random.randint(0, 2)):
                    pos = random.randint(0, len(seq))
                    seq.insert(pos, '-')
                bacterium.append(seq)
            poblacion[i] = tuple(bacterium)  # <-- Asegúrate de guardar la bacteria
            
   




    def printPoblacion():
        for i in range(numeroDeBacterias):
            print(poblacion[i])
            
            
    
            
    

    #---------------------------------------------------------------------------------------------------------
    operadorBacterial = bacteria(numeroDeBacterias)    
    veryBest = [None, None, None] #indice, fitness, secuencias
    
    #registra el tiempo de inicio
    start_time = time.time()
    
    print("poblacion inicial ...")
    poblacionInicial() 
    
    ventana = 5  # Puedes ajustar el tamaño de la ventana
    historial_fitness = []
    historial_diversidad = []
    
    tumbo_min = 1
    tumbo_max = 10
    
    for it in range(iteraciones):
        print("poblacion inicial creada - Tumbo ...")
        tumbo_iter = max(tumbo_min, min(tumbo, tumbo_max))
        operadorBacterial.tumbo(numSec, poblacion, tumbo_iter)
        print("Tumbo Realizado - Cuadrando ...")
        operadorBacterial.cuadra(numSec, poblacion)
        print("poblacion inicial cuadrada - Creando granLista de Pares...")
        operadorBacterial.refinamiento_local(poblacion)
        operadorBacterial.creaGranListaPares(poblacion)
        print("granList: creada - Evaluando Blosum Parallel")
        operadorBacterial.evaluaBlosum()  #paralelo
        print("blosum evaluado - creando Tablas Atract Parallel...")

        operadorBacterial.creaTablasAtractRepel(poblacion, dAttr, wAttr,hRep, wRep)


        operadorBacterial.creaTablaInteraction()
        print("tabla Interaction creada - creando tabla Fitness")
        operadorBacterial.creaTablaFitness()
        print("tabla Fitness creada ")
        globalNFE += operadorBacterial.getNFE()
        bestIdx, bestFitness = operadorBacterial.obtieneBest(globalNFE)
        historial_fitness.append(bestFitness)
        pad_poblacion(poblacion)
        div = diversidad_poblacion_vectorizada(poblacion)
        historial_diversidad.append(div)

    if it >= ventana and it % ventana == 0:
        mejora = historial_fitness[it] - historial_fitness[it-ventana]
        div_actual = np.mean(historial_diversidad[-ventana:])
        if mejora > 0:
            wAttr *= 1.2
            wRep *= 0.8
            tumbo = max(1, int(tumbo * 0.9))
            print(f"Mejora detectada: wAttr->{wAttr:.4f}, wRep->{wRep:.4f}, tumbo->{tumbo}")
        elif mejora < 1e-6 and div_actual < 0.1:
            wRep *= 1.1
            wAttr *= 0.95
            tumbo = min(50, tumbo + 1)
            print(f"Estancado: wRep->{wRep:.4f}, wAttr->{wAttr:.4f}, tumbo->{tumbo}")

    # --- RESTO DEL CICLO ---
    if veryBest[0] is not None:
        poblacion[0] = copy.deepcopy(veryBest[2])

    if (veryBest[0] is None) or (bestFitness > veryBest[1]):
        veryBest[0] = bestIdx
        veryBest[1] = bestFitness
        veryBest[2] = copy.deepcopy(poblacion[bestIdx])
    operadorBacterial.replaceWorst(poblacion, veryBest[0])
    operadorBacterial.resetListas(numeroDeBacterias)
    
    print(f"Iteración {it}: Fitness de la población: {[operadorBacterial.tablaFitness[i] for i in range(numeroDeBacterias)]}")
    print(f"Mejor fitness hasta ahora: {veryBest[1]}")

    print("Very Best: ", veryBest)
    #imprime el tiempo de ejecucion
    print("--- %s seconds ---" % (time.time() - start_time))



    