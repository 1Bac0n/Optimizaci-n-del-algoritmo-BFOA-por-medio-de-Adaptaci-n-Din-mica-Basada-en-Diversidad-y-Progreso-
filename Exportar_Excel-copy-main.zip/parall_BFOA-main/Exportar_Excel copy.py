import time
import pandas as pd
import matplotlib.pyplot as plt
from parallel_BFOA import bacteria, fastaReader

def ejecutar_experimento(numRandomBacteria=1, nado=3):
    numeroDeBacterias = 8
    iteraciones = 15
    tumbo = 20  #valor bajo para evitar destrucción excesiva
    dAttr = 0.1
    wAttr = 0.002
    hRep = dAttr
    wRep = 0.001

    secuencias = fastaReader().seqs
    names = fastaReader().names
    for i in range(len(secuencias)):
        secuencias[i] = list(secuencias[i])

    numSec = len(secuencias)
    poblacion = [None] * numeroDeBacterias

    def poblacionInicial():
        for i in range(numeroDeBacterias):
            bacterium = []
            for j in range(numSec):
                seq = secuencias[j][:]
                for _ in range(0,10):  # pocos gaps iniciales
                    pos = random.randint(0, len(seq))
                    seq.insert(pos, '-')
                bacterium.append(seq)
            poblacion[i] = list(bacterium)

    operadorBacterial = bacteria(numeroDeBacterias)
    veryBest = [None, None, None]
    globalNFE = 0

    start_time = time.time()
    poblacionInicial()
    for it in range(iteraciones):
        operadorBacterial.tumbo(numSec, poblacion, tumbo)
        operadorBacterial.cuadra(numSec, poblacion)
        operadorBacterial.refinamiento_local(poblacion)  # Usa tu refinamiento mejorado
        operadorBacterial.creaGranListaPares(poblacion)
        operadorBacterial.evaluaBlosum()
        operadorBacterial.creaTablasAtractRepel(poblacion, dAttr, wAttr, hRep, wRep)
        operadorBacterial.creaTablaInteraction()
        operadorBacterial.creaTablaFitness()
        globalNFE += operadorBacterial.getNFE()
        bestIdx, bestFitness = operadorBacterial.obtieneBest(globalNFE)
        if (veryBest[0] is None) or (bestFitness > veryBest[1]):
            veryBest[0] = bestIdx
            veryBest[1] = bestFitness
            veryBest[2] = [seq[:] for seq in poblacion[bestIdx]]
        operadorBacterial.replaceWorst(poblacion, veryBest[0])
        operadorBacterial.resetListas(numeroDeBacterias)

    tiempo = time.time() - start_time
    bestIdx = veryBest[0]
    fitness = veryBest[1]
    blosum = operadorBacterial.blosumScore[bestIdx]
    interaction = operadorBacterial.tablaInteraction[bestIdx]
    return fitness, blosum, interaction, tiempo

if __name__ == "__main__":
    import random
    resultados = []
    for corrida in range(3):  #ejecuciones
        fitness, blosum, interaction, tiempo = ejecutar_experimento()
        resultados.append({
            "Corrida": corrida + 1,
            "Fitness": fitness,
            "Blosum": blosum,
            "Interaccion": interaction,
            "Tiempo (s)": tiempo
        })
        print(f"Corrida {corrida+1}: Fitness={fitness}, Blosum={blosum}, Interaccion={interaction}, Tiempo={tiempo:.2f}s")

    df = pd.DataFrame(resultados)
    df.to_excel("resultados_corridas6.xlsx", index=False)

    plt.figure(figsize=(10,6))
    plt.subplot(2,2,1)
    plt.plot(df["Corrida"], df["Fitness"], marker='o')
    plt.title("Fitness por corrida")
    plt.xlabel("Corrida")
    plt.ylabel("Fitness")

    plt.subplot(2,2,2)
    plt.plot(df["Corrida"], df["Blosum"], marker='o', color='orange')
    plt.title("Blosum por corrida")
    plt.xlabel("Corrida")
    plt.ylabel("Blosum")

    plt.subplot(2,2,3)
    plt.plot(df["Corrida"], df["Interaccion"], marker='o', color='green')
    plt.title("Interacción por corrida")
    plt.xlabel("Corrida")
    plt.ylabel("Interacción")

    plt.subplot(2,2,4)
    plt.plot(df["Corrida"], df["Tiempo (s)"], marker='o', color='red')
    plt.title("Tiempo de ejecución por corrida")
    
    plt.tight_layout()
    plt.savefig("graficos_corridas5.png")
    plt.show()
    plt# filepath: c:\Users\skila\OneDrive\Documentos\01Universidad\Nueva carpeta\parall_BFOA-main\parall_BFOA-main\Exportar_Excel copy.py
